file="100-CC-Records.csv"
export IFS=","
now="$(date +'%m%Y')"
echo $now	
cond="$(date +'%s')"
echo $cond
while read f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11
do
	exten="expired"
	varA= echo $f8 | tr '/' ' '
	echo $varA
	oldIFS=$IFS
	IFS=/
	set -f
	set -- $f8
	set +f
	IFS=$oldIFS
	date1=01/$1/$2
	echo $date1
	read mon year <<< $varA
	varB="$(date -d "$date1" '+%s')"
	echo $varB
	if [ "$varB" -ge "$cond" ]
	then
		exten="active"
	fi
	if [ ! -d "$f2" ]
	then
		mkdir ./$f2
	fi
	if [ ! -d "$f2/$f3" ]
	then
		mkdir ./$f2/$f3
	fi
	filePath=$f2/$f3/$f4.$exten
	echo $filePath
	echo "Card Type Code: $f1" >> $filePath
	echo "Card Type Full Name: $f2" >> $filePath
	echo "Issuing Bank: $f3" >> $filePath
	echo "Card Number: $f4" >> $filePath
	echo "Card Holder's Name: $f5" >> $filePath
	echo "CVV/CVV2: $f6" >> $filePath
	echo "Issue Date: $f7" >> $filePath
	echo "Expiry Date: $f8" >> $filePath
	echo "Billing Date: $f9" >> $filePath
	echo "Card PIN: $f10" >> $filePath
	echo -n "Credit Limit: \$">> $filePath
	printf -v a '%d\n' $f11 >/dev/null
	echo -n $a | numfmt --g $a >> $filePath
done < "100-CC-Records.csv"